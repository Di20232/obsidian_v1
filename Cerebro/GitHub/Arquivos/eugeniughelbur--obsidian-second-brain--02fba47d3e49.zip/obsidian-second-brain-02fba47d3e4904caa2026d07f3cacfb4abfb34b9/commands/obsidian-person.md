---
description: Create or update a person note from conversation context
category: vault
trigger-mode: proactive
triggers_en: ["save this person", "add person", "new contact note", "create person note"]
triggers_es: ["guarda a esta persona", "añade una persona", "nueva nota de contacto", "crea una nota de persona"]
triggers_pt: ["salve esta pessoa", "adicione uma pessoa", "nova nota de contato", "crie uma nota de pessoa"]
triggers_zh: ["保存这个人的信息", "新建联系人笔记", "为这个人建档", "更新这个人的资料"]
---

Use the obsidian-second-brain skill. Execute `/obsidian-person $ARGUMENTS`:

The argument is a person's name - handle typos and partial matches.

1. Read `_CLAUDE.md` first if it exists in the vault root
2. Search the vault for an existing note matching the name (fuzzy - handle typos and partial names)
3. If found: confirm with user, then update with new info from conversation
4. If not found: create `Full Name.md` in the entities folder (resolved per `references/folder-map.md` - wiki-style `wiki/entities/`, Obsidian-style `People/`) with full frontmatter schema
5. Fill in everything inferable from the conversation: role, company, context, relationship strength, last interaction date
6. Log the interaction in today's daily note
7. If a People index file exists, add or update the entry there

If the name has a typo or is approximate, search the vault, show what was found, and confirm before proceeding. Never silently create a note with a misspelled name.

---

**AI-first rule:** Every note created or updated by this command MUST follow `references/ai-first-rules.md` - `## For future agent` preamble, rich frontmatter (`type`, `date`, `tags`, `ai-first: true`, plus type-specific fields), recency markers per external claim, mandatory `[[wikilinks]]` for every person/project/concept referenced, sources preserved verbatim with URLs inline, and confidence levels where applicable. If that path does not resolve from your working directory, search upward for it; if you still cannot read it, say so before writing rather than producing a note that silently skips the rule. The vault is for future agent retrieval - not human reading.

**Anti-fabrication:** Search exhaustively before claiming any note, person, or file is absent - false absence is the most common failure mode - and never invent facts, entities, or dates (mark unknowns as `TBD`). See the anti-fabrication and search-completeness hard rules in `references/ai-first-rules.md`.
