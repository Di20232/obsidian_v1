---
description: Scan X for what's trending in a topic - themes, voices, hooks, and post ideas powered by Grok x_search
category: research
triggers_en: ["x pulse", "what is trending on twitter", "scan x for", "twitter pulse"]
triggers_es: ["x pulse", "qué es tendencia en twitter", "escanea x en busca de", "pulso de twitter"]
triggers_pt: ["x pulse", "o que está em alta no x", "escaneie o x em busca de", "pulso do twitter"]
triggers_zh: ["看看 X 上这个话题的趋势", "推特上这个话题有什么热点", "扫描 X 上的热门讨论", "分析这个主题的社交媒体风向"]
---

Use the obsidian-second-brain skill. Execute `/x-pulse [topic]`:

1. Resolve the topic from the user's argument. Multi-word topics are fine ("AI automation", "vibe coding"). If no topic was given, ask: "What topic should I scan X for?"

2. Run the script from the skill root (its absolute path was given at session start as **Skill root**; substitute it for `SKILL_ROOT`):
   ```bash
   uv run --directory "SKILL_ROOT" -m scripts.research.x_pulse "<topic>"
   ```

3. The script returns a structured pulse: WHAT'S HOT (themes with rep posts + voices), WHAT'S UNDEREXPLORED (gaps), HOOKS THAT ARE WORKING, VOICE & TONE WORKING, POST IDEAS FOR YOU TODAY. Show the full output to the user verbatim.

4. **Default save behavior: saves automatically.** The script writes an AI-first note to `Research/X-pulse/YYYY-MM-DD - <slug>.md` with the AI-first vault rule applied (preamble, frontmatter, recency markers, sources verbatim). It also appends a one-line entry to `log.md`.

5. After printing, mention to the user the file path that was saved (the script prints this on stderr, surface it cleanly).

6. Plain English triggers that route to this command: "what's hot on X about [topic]", "X pulse on [topic]", "what should I post about [topic] today", "scan X for [topic]", "trends on X about [topic]".

7. If the script reports "No active discourse found in last 72h on this topic", offer to either broaden the topic or try `/research [topic]` instead (Perplexity for general web research).

8. If the script fails with a clear error, surface it verbatim. Auto-retry on transient errors is handled inside the script.

---

**AI-first rule:** Every note created or updated by this command MUST follow `references/ai-first-rules.md` - `## For future agent` preamble, rich frontmatter (`type`, `date`, `tags`, `ai-first: true`, plus type-specific fields), recency markers per external claim, mandatory `[[wikilinks]]` for every person/project/concept referenced, sources preserved verbatim with URLs inline, and confidence levels where applicable. If that path does not resolve from your working directory, search upward for it; if you still cannot read it, say so before writing rather than producing a note that silently skips the rule. The vault is for future agent retrieval - not human reading.

**Anti-fabrication:** Search exhaustively before claiming any note, person, or file is absent - false absence is the most common failure mode - and never invent facts, entities, or dates (mark unknowns as `TBD`). See the anti-fabrication and search-completeness hard rules in `references/ai-first-rules.md`.
