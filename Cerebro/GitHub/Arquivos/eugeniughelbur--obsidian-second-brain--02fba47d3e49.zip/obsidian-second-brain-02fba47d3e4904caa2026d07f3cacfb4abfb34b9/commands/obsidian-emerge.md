---
description: Surface unnamed patterns from your recent notes - recurring themes, hidden connections, and conclusions you haven't explicitly stated
category: thinking
triggers_en: ["find patterns", "what is emerging", "surface themes", "unnamed patterns"]
triggers_es: ["busca patrones", "qué está emergiendo", "patrones que no he nombrado", "qué patrones ves aquí", "qué se repite en mis notas"]
triggers_pt: ["encontre padrões", "o que está emergindo", "mostre temas", "padrões sem nome"]
triggers_zh: ["从最近的笔记里找规律", "最近有什么趋势正在浮现", "找出我还没说清的模式", "看看反复出现的主题"]
---

Use the obsidian-second-brain skill. Execute `/obsidian-emerge $ARGUMENTS`:

The optional argument is a timeframe (e.g., "2 weeks", "this month"). Default: last 30 days.

1. Read `_CLAUDE.md` first if it exists in the vault root
2. Determine the date range from the argument (default: last 30 days)
3. Spawn parallel subagents to read vault content from the period:
   - **Daily notes agent**: read all daily notes in the date range, extract recurring topics, complaints, observations, and energy patterns
   - **Dev logs agent**: read all dev logs in the range, extract repeated blockers, tools mentioned, architectural patterns
   - **Decisions agent**: read Key Decisions sections across project notes, look for directional trends
   - **Ideas agent**: read notes created in the range in the ideas/concepts folder (resolved per `references/folder-map.md` - wiki-style `wiki/concepts/`, Obsidian-style `Ideas/`), look for thematic clusters
4. Merge results and identify:
   - **Recurring themes**: topics that appeared 3+ times without being named as a priority
   - **Emotional patterns**: what energizes vs. drains the user (based on language and context)
   - **Unnamed conclusions**: things the notes imply but never state outright (e.g., "you've mentioned onboarding friction in 4 different projects - this is a systemic issue, not a project-specific one")
   - **Emerging directions**: where the vault suggests the user is heading, even if they haven't committed to it
5. Present findings as a structured "Pattern Report" - each pattern gets: the evidence (cited notes), the interpretation, and a suggested action
6. Offer to save the pattern report to the ideas/concepts folder (resolved per `references/folder-map.md` - wiki-style `wiki/concepts/`, Obsidian-style `Ideas/`) or a relevant project note; standalone reports use `type: emerge` (thinking-tool schema in `references/ai-first-rules.md`), named `YYYY-MM-DD - emerge.md`
7. Log a brief summary in today's daily note

The goal is insight the user cannot see themselves. Do not restate what they already know - surface what they haven't named yet.

---

**AI-first rule:** Every note created or updated by this command MUST follow `references/ai-first-rules.md` - `## For future agent` preamble, rich frontmatter (`type`, `date`, `tags`, `ai-first: true`, plus type-specific fields), recency markers per external claim, mandatory `[[wikilinks]]` for every person/project/concept referenced, sources preserved verbatim with URLs inline, and confidence levels where applicable. If that path does not resolve from your working directory, search upward for it; if you still cannot read it, say so before writing rather than producing a note that silently skips the rule. The vault is for future agent retrieval - not human reading.

**Anti-fabrication:** Search exhaustively before claiming any note, person, or file is absent - false absence is the most common failure mode - and never invent facts, entities, or dates (mark unknowns as `TBD`). See the anti-fabrication and search-completeness hard rules in `references/ai-first-rules.md`.
