"""Exercicio 05 - sistema escolar com estruturas de selecao.

Variacao B (orientada a objetos): o aluno e a avaliacao viram dataclasses
que sabem decidir a propria situacao, e os menus sao objetos Menu com as
opcoes registradas uma a uma.
"""

from dataclasses import dataclass, field

LARGURA = 50


# ---------------------------------------------------------------- entradas


class LeitorDeDados:
    """Perguntas de teclado que so devolvem valores validos."""

    @staticmethod
    def numero(mensagem, minimo=0, maximo=10):
        while True:
            try:
                valor = float(input(mensagem))
            except ValueError:
                print("Entrada inválida. Digite um número válido.")
                continue

            if minimo <= valor <= maximo:
                return valor

            print(f"Valor fora do intervalo permitido ({minimo} a {maximo}).")

    @staticmethod
    def inteiro(mensagem, minimo=0):
        while True:
            try:
                valor = int(input(mensagem))
            except ValueError:
                print("Entrada inválida. Digite um número inteiro.")
                continue

            if valor >= minimo:
                return valor

            print(f"Digite um valor maior ou igual a {minimo}.")

    @staticmethod
    def confirmar(mensagem):
        return input(mensagem).strip().lower() == "s"


# ------------------------------------------------------------------ regras


@dataclass
class Aluno:
    """Um aluno com nota e faltas, capaz de dizer a propria situacao."""

    nome: str
    nota: float
    faltas: int = 0

    def situacao(self):
        if self.nota >= 9.0:
            return f"{self.nome}: ALUNO DESTAQUE - Nota {self.nota}"
        if self.nota >= 7.0 and self.faltas <= 10:
            return f"{self.nome}: APROVADO - Nota {self.nota}, Faltas {self.faltas}"
        if self.nota >= 5.0 and self.faltas <= 10:
            return f"{self.nome}: EM RECUPERACAO - Nota {self.nota}, Faltas {self.faltas}"
        return f"{self.nome}: REPROVADO - Nota {self.nota}, Faltas {self.faltas}"


@dataclass
class Avaliacao:
    """Nota e frequencia de um aluno em um periodo."""

    nota: float
    frequencia: float

    def resultado(self):
        if self.frequencia >= 75 and self.nota >= 7.0:
            return "RESULTADO: APROVADO - Nota e frequencia suficientes"
        if self.frequencia >= 75:
            return f"RESULTADO: REPROVADO - Frequencia OK, mas nota {self.nota} abaixo de 7.0"
        return f"RESULTADO: REPROVADO - Frequencia {self.frequencia}% abaixo de 75%"


@dataclass
class Boletim:
    """Uma nota isolada, so para ser classificada."""

    nota: float

    def classificacao(self):
        if self.nota >= 9.0:
            return "EXCELENTE"
        if self.nota >= 7.0:
            return "BOM"
        if self.nota >= 5.0:
            return "REGULAR"
        if self.nota >= 3.0:
            return "RUIM"
        return "PESSIMO"


class Turma:
    """Uma colecao de alunos cadastrados no teclado."""

    def __init__(self):
        self.alunos = []

    def cadastrar(self, aluno):
        self.alunos.append(aluno)

    def __bool__(self):
        return bool(self.alunos)

    def imprimir_resultados(self):
        print("\n" + "-" * 30)
        print("RESULTADOS:")
        print("-" * 30)
        for aluno in self.alunos:
            print(aluno.situacao())


# ------------------------------------------------------------------- acoes


class SistemaEscolar:
    """Reune as acoes que os menus podem disparar."""

    OPCOES_PROCESSADOR = {
        "1": "OPCAO 1: Listar alunos",
        "2": "OPCAO 2: Cadastrar aluno",
        "3": "OPCAO 3: Calcular media",
        "4": "OPCAO 4: Sair do sistema",
        "sair": "OPCAO 4: Sair do sistema",
    }

    def verificar_aprovacao(self):
        print("\n=== VERIFICACAO DE APROVACAO ===")

        avaliacao = Avaliacao(
            nota=LeitorDeDados.numero("Digite a nota do aluno (0 a 10): ", 0, 10),
            frequencia=LeitorDeDados.numero("Digite a frequencia do aluno (0 a 100): ", 0, 100),
        )

        print(f"Nota: {avaliacao.nota} - Frequencia: {avaliacao.frequencia}%")
        print(avaliacao.resultado())

    def classificar_nota(self):
        print("\n=== CLASSIFICACAO DE NOTA ===")

        boletim = Boletim(LeitorDeDados.numero("Digite a nota para classificar (0 a 10): ", 0, 10))

        print(f"Nota: {boletim.nota}")
        print(f"CLASSIFICACAO: {boletim.classificacao()}")

    def processar_menu(self):
        print("\n=== PROCESSADOR DE MENU ===")
        print("1 - Listar alunos")
        print("2 - Cadastrar aluno")
        print("3 - Calcular media")
        print("4 - Sair do sistema")

        opcao = input("Digite a opcao desejada: ")

        print(self.OPCOES_PROCESSADOR.get(opcao, f"OPCAO INVALIDA: {opcao}"))

    def avaliar_aluno(self):
        print("\n=== AVALIACAO DO ALUNO ===")

        aluno = Aluno(
            nome=input("Digite o nome do aluno: "),
            nota=LeitorDeDados.numero("Digite a nota do aluno (0 a 10): ", 0, 10),
            faltas=LeitorDeDados.inteiro("Digite o numero de faltas: ", 0),
        )

        print(f"Aluno: {aluno.nome} - Nota: {aluno.nota} - Faltas: {aluno.faltas}")
        print(aluno.situacao())

    def _repetir(self, acao, pergunta):
        while True:
            acao()
            if not LeitorDeDados.confirmar(pergunta):
                break

    def verificar_multiplos_alunos(self):
        print("\n=== VERIFICAR MULTIPLOS ALUNOS ===")
        self._repetir(self.verificar_aprovacao, "\nVerificar outro aluno? (s/n): ")

    def classificar_multiplas_notas(self):
        print("\n=== CLASSIFICAR MULTIPLAS NOTAS ===")
        self._repetir(self.classificar_nota, "\nClassificar outra nota? (s/n): ")

    def processar_lista_alunos(self):
        print("\n=== PROCESSAR LISTA DE ALUNOS ===")

        turma = Turma()
        while True:
            turma.cadastrar(
                Aluno(
                    nome=input("Nome do aluno: "),
                    nota=LeitorDeDados.numero("Nota (0 a 10): ", 0, 10),
                    faltas=LeitorDeDados.inteiro("Faltas: ", 0),
                )
            )

            if not LeitorDeDados.confirmar("Adicionar outro aluno? (s/n): "):
                break

        if turma:
            turma.imprimir_resultados()


# ------------------------------------------------------------------- menus


@dataclass
class Menu:
    """Um menu de tela: cabecalho, opcoes registradas e laco de repeticao."""

    cabecalho: tuple
    subtitulo: str
    prompt: str
    saidas_extras: tuple = ()
    _opcoes: dict = field(default_factory=dict)

    def registrar(self, tecla, rotulo, acao=None):
        """Registra uma opcao; acao None significa 'sair do menu'."""
        self._opcoes[tecla] = (rotulo, acao)
        return self

    def _mostrar_cabecalho(self):
        for linha in self.cabecalho:
            print(linha)

    def _mostrar_opcoes(self):
        print("\n" + "-" * LARGURA)
        print(self.subtitulo)
        print("-" * LARGURA)
        for tecla, (rotulo, _) in self._opcoes.items():
            print(f"{tecla} - {rotulo}")

    def executar(self):
        self._mostrar_cabecalho()

        while True:
            self._mostrar_opcoes()

            escolha = input(self.prompt)
            item = self._opcoes.get(escolha)

            if escolha in self.saidas_extras or (item is not None and item[1] is None):
                print("\nSaindo do sistema...")
                return

            if item is None:
                print("\nOPCAO INVALIDA! Tente novamente.")
            else:
                item[1]()

            input("\nPressione Enter para continuar...")


def main():
    sistema = SistemaEscolar()

    menu = Menu(
        cabecalho=(
            "=" * LARGURA,
            "SISTEMA ESCOLAR SIMPLES",
            "Demonstracao de estruturas de selecao",
            "=" * LARGURA,
        ),
        subtitulo="MENU PRINCIPAL",
        prompt="\nEscolha uma opcao (1-5): ",
    )
    menu.registrar("1", "Verificar Aprovacao", sistema.verificar_aprovacao)
    menu.registrar("2", "Classificar Nota", sistema.classificar_nota)
    menu.registrar("3", "Processar Menu", sistema.processar_menu)
    menu.registrar("4", "Avaliar Aluno", sistema.avaliar_aluno)
    menu.registrar("5", "Sair")
    menu.executar()


def menu_avancado():
    sistema = SistemaEscolar()

    menu = Menu(
        cabecalho=(
            "=" * LARGURA,
            "SISTEMA ESCOLAR - MENU AVANCADO",
            "=" * LARGURA,
        ),
        subtitulo="OPCOES:",
        prompt="\nEscolha uma opcao: ",
        saidas_extras=("sair",),
    )
    menu.registrar("1", "Verificar Aprovacao", sistema.verificar_aprovacao)
    menu.registrar("2", "Classificar Nota", sistema.classificar_nota)
    menu.registrar("3", "Processar Menu", sistema.processar_menu)
    menu.registrar("4", "Avaliar Aluno", sistema.avaliar_aluno)
    menu.registrar("5", "Verificar Multiplos Alunos", sistema.verificar_multiplos_alunos)
    menu.registrar("6", "Classificar Multiplas Notas", sistema.classificar_multiplas_notas)
    menu.registrar("7", "Processar Lista de Alunos", sistema.processar_lista_alunos)
    menu.registrar("8", "Sair")
    menu.executar()


def testar_rapido():
    sistema = SistemaEscolar()

    testes = {
        "1": ("Testar Aprovacao", sistema.verificar_aprovacao),
        "2": ("Testar Classificacao", sistema.classificar_nota),
        "3": ("Testar Match Case", sistema.processar_menu),
        "4": ("Testar Guarda", sistema.avaliar_aluno),
    }

    print("\n=== TESTE RAPIDO ===")
    for tecla, (rotulo, _) in testes.items():
        print(f"{tecla} - {rotulo}")

    teste = testes.get(input("Escolha um teste (1-4): "))

    if teste is None:
        print("Opcao invalida!")
    else:
        teste[1]()


def escolher_versao():
    versoes = {
        "1": ("Menu Interativo", main),
        "2": ("Menu Avancado", menu_avancado),
        "3": ("Teste Rapido", testar_rapido),
        "4": ("Sair", None),
    }

    print("=" * LARGURA)
    print("SISTEMA ESCOLAR - VERSOES DISPONIVEIS")
    print("=" * LARGURA)
    for tecla, (rotulo, _) in versoes.items():
        print(f"{tecla} - {rotulo}")

    versao = versoes.get(input("\nEscolha uma versao (1-4): "))

    if versao is None:
        print("Opcao invalida!")
    elif versao[1] is None:
        print("Saindo...")
    else:
        versao[1]()


if __name__ == "__main__":
    escolher_versao()
